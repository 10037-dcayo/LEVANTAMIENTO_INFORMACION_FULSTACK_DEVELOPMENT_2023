# LEVANTAMIENTO_INFORMACION_FULSTACK_DEVELOPMENT_2023

SHARED REPOSITORY OF THE DATA COLLECTION DEVELOPMENT TEAM, FOR FRONTEND AND BACKEND

Control de Registros

- ESPE 2023 

# sudo 
user: admin

pass: root

![image](https://user-images.githubusercontent.com/43613125/160877647-2228e861-b991-419a-85cd-326550f49c50.png)

![image](https://user-images.githubusercontent.com/43613125/160877412-0c69c15e-c034-410d-bb00-7cd71bff8d6f.png)
