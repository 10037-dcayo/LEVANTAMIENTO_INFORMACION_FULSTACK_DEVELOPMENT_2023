<?php
header('Location: /');
exit();